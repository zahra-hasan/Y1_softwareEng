get "/help-mentee" do
   erb :help_mentee
end
