get "/help-mentor" do
   erb :help_mentor
end