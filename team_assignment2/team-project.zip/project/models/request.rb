class Request < Sequel::Model
end