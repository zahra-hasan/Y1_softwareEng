class Code < Sequel::Model
end